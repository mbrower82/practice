﻿using CandyShop.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CandyShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Chocolate()
        {
            ChocolateViewModel cvm = new ChocolateViewModel();

            List<DTO.Chocolate> chocolates = new List<DTO.Chocolate>()
            {
                new DTO.Chocolate{ Name = "Milk Chocolate", Weight = 2, Price = 2.50 },
                new DTO.Chocolate{ Name = "Dark Chocolate", Weight = 3, Price = 4.50 },
                new DTO.Chocolate{ Name = "White Chocolate", Weight = 5, Price = 6.00 },

            };
            cvm.Chocolates = chocolates; 

            return View(cvm);
        }
        public IActionResult BubbleGum()
        {
            BubbleGumViewModel bvm = new BubbleGumViewModel();

            List<DTO.BubbleGum> bubblegums = new List<DTO.BubbleGum>()
            {
                new DTO.BubbleGum{ BGName = "Fruit Punch", BGWeight = 1, BGPrice = 2.50 },
                new DTO.BubbleGum{ BGName = "Grape", BGWeight = 1, BGPrice = 2.50 },
                new DTO.BubbleGum{ BGName = "Cherry", BGWeight = 1, BGPrice = 2.50 },
            };
            bvm.BubbleGums = bubblegums;

            return View(bvm);
        }
        public IActionResult Licorice()
        {
            LicoriceViewModel lvm = new LicoriceViewModel();

            List<DTO.Licorice> licorices = new List<DTO.Licorice>()
            {
                new DTO.Licorice{ LName = "Twislers", LWeight = 3, LPrice = 3.50 },
                new DTO.Licorice{ LName = "Nibs", LWeight = 3, LPrice = 3.50 },
                new DTO.Licorice{ LName = "Black", LWeight = 3, LPrice = 3.50 },
            };
            lvm.Licorices = licorices;

            return View(lvm);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}