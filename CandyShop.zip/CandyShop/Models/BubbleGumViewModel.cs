﻿namespace CandyShop.Models
{
    public class BubbleGumViewModel
    {
        public List<DTO.BubbleGum> BubbleGums { get; set; }
    }
}
