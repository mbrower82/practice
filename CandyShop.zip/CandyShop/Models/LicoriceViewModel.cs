﻿namespace CandyShop.Models
{
    public class LicoriceViewModel
    {
        public List<DTO.Licorice> Licorices { get; set; }
    }
}
