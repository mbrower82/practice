﻿namespace CandyShop.Models
{
    public class ChocolateViewModel
    {
        public List<DTO.Chocolate> Chocolates { get; set; }
    }
}
