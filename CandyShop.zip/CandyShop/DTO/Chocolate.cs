﻿namespace CandyShop.DTO
{
    public class Chocolate
    {
        public string Name { get; set; }
        public int Weight { get; set; }
        public double Price { get; set; }
    }
}
