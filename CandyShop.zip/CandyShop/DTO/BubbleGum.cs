﻿namespace CandyShop.DTO
{
    public class BubbleGum
    {
        public string BGName { get; set; }
        public int BGWeight { get; set; }
        public double BGPrice { get; set; }
    }
}
