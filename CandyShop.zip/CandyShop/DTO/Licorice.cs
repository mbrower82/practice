﻿namespace CandyShop.DTO
{
    public class Licorice
    {
        public string LName { get; set; }
        public int LWeight { get; set; }
        public double LPrice { get; set; }
    }
}
